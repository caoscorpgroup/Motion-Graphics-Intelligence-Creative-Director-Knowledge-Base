import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class PackageTests(unittest.TestCase):
    def test_skill_frontmatter(self):
        text = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
        self.assertTrue(text.startswith('---\nname: director-creativo-motion-graphics\n'))
        self.assertIn('version: "0.4.0"', text)

    def test_reference_map_points_to_existing_files(self):
        text = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
        refs = re.findall(r'`((?:references|workflows)/[^`]+\.md)`', text)
        self.assertGreaterEqual(len(refs), 10)
        for ref in refs:
            with self.subTest(reference=ref):
                self.assertTrue((ROOT / ref).is_file(), ref)

    def test_demo_sources_exist(self):
        demo = ROOT / 'examples' / 'motion-intelligence-demo'
        for name in ('index.html', 'style.css', 'motion.js'):
            with self.subTest(file=name):
                self.assertTrue((demo / name).is_file())

    def test_svg_is_the_default_contract(self):
        text = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('El entregable visual predeterminado es SVG animado e interactivo', text)
        self.assertIn('No generes MP4, GIF ni imágenes rasterizadas como salida predeterminada.', text)
        self.assertTrue((ROOT / 'references' / 'technical-standards.md').is_file())
        self.assertFalse((ROOT / 'examples' / 'motion-intelligence-demo' / 'preview.mp4').exists())

    def test_old_project_template_is_preserved(self):
        template = ROOT / 'templates' / 'project-template'
        for name in ('README.md', 'PROJECT_STATE.md', 'SESSION_LOG.md', 'index.html', 'style.css', 'motion.js'):
            with self.subTest(file=name):
                self.assertTrue((template / name).is_file())

if __name__ == '__main__':
    unittest.main()
