# Motion Intelligence Demo

Prueba técnica vector-first de 12 segundos. Abre `index.html` en un navegador moderno. La escena se construye con SVG editable y CSS; `motion.js` contiene la lógica auxiliar. No se incluye MP4: el entregable fuente es la composición vectorial y cualquier exportación audiovisual es opcional.
