# Estándares técnicos — SVG-first

## Fuente y estructura
- El formato fuente y entregable predeterminado es SVG animado e interactivo.
- Usa `viewBox` para escalado, `preserveAspectRatio` según composición, IDs estables y grupos `<g>` semánticos para capas.
- Separa fondo, escenario, personajes, objetos, iluminación, tipografía, efectos y controles cuando sea útil para edición o animación.
- Prefiere SVG autónomo con estilos y animaciones embebidos. Usa recursos locales y rutas relativas; evita enlaces remotos y dependencias innecesarias.
- Mantén SVG válido como XML. Escapa caracteres, evita IDs duplicados y verifica referencias `url(#id)`.

## Movimiento e interacción
- CSS: transiciones, keyframes, transformaciones y estados visuales.
- SMIL: animaciones declarativas dentro del SVG cuando simplifique la pieza y el soporte del visor esté comprobado.
- JavaScript: botones, interruptores, navegación entre escenas, estados, eventos y lógica interactiva. Usa listeners y controles accesibles; evita código inline inseguro si el destino lo restringe.
- Organiza escenas mediante grupos identificables y estados de visibilidad/animación. Define duración, pausas, sincronización, repetición y comportamiento de reinicio.
- Respeta `prefers-reduced-motion` en contextos web y ofrece controles de pausa/reinicio cuando la animación lo requiera.

## Visores y empaquetado
- Comprueba el SVG en un navegador moderno. Los visores de archivos, previsualizadores y aplicaciones pueden bloquear scripts o animaciones; documenta las limitaciones reales.
- Si la interacción requiere un contexto web, entrega también `index.html` con el SVG y sus recursos locales. El HTML es el contenedor; el SVG sigue siendo la fuente gráfica.
- Verifica funcionamiento sin conexión cuando sea un requisito. No dependas de CDN si no es necesario.

## Exportaciones secundarias
- No exportes MP4, GIF, PNG ni otros formatos automáticamente. El SVG editable es el producto fuente.
- Si el usuario pide una exportación, conserva el SVG original y genera el formato solicitado como copia derivada. Comprueba dimensiones, fps, códec y duración solo para exportaciones audiovisuales.

## QA
Valida XML, IDs, capas, rutas, fuentes, estilos, scripts, controles, escalado, animación real, rendimiento y compatibilidad. Distingue lo que fue generado, ejecutado, inspeccionado y probado en cada visor.
