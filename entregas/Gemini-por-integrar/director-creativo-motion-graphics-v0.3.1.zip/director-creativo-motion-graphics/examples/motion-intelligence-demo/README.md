# Motion Intelligence Demo

A 12-second, 16:9 vector-first motion-graphics study. It tests a complete mini-sequence: character entrance, layered infographic reveal, typography tags, secondary motion, a designed pause and a looped progress line.

Open `index.html` in a modern browser. All visual elements are editable SVG/CSS; no generated image assets are used.
