// The composition is intentionally authored from editable SVG primitives and CSS motion.
// Restart the 12-second loop when the document becomes visible.
const stage = document.querySelector('.stage');
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    stage.classList.remove('restart');
    void stage.offsetWidth;
    stage.classList.add('restart');
  }
});
