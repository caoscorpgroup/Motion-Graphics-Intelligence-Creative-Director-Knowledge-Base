import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import palette,typography
class Tests(unittest.TestCase):
 def test_hex(self):self.assertEqual(palette.parse_hex('#abc'),palette.parse_hex('#AABBCC'))
 def test_triadic(self):self.assertEqual(len(palette.harmony('#336699','triadic')),3)
 def test_bad_hex(self):
  with self.assertRaises(ValueError):palette.parse_hex('nope')
 def test_fluid(self):self.assertTrue(typography.fluid_type().startswith('clamp('))
 def test_escape(self):self.assertIn('&lt;',typography.kinetic_title('<X>'))
if __name__=='__main__':unittest.main()
