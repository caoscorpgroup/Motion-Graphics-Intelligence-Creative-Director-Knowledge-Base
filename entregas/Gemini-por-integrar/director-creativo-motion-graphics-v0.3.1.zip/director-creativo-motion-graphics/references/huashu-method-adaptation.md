# Adaptación metodológica: huashu-art-motion

**Fuente:** https://github.com/alchaincyf/huashu-art-motion  
**Licencia declarada por el proyecto:** MIT para código y documentación, con excepciones expresas para ciertos personajes, materiales y recursos.  
**Uso en este skill:** inspiración metodológica y síntesis original; no se copian assets, personajes, muestras, ni código del repositorio.

## Métodos incorporados
- Clasificar el trabajo antes de seleccionar técnicas.
- Analizar referencias audiovisuales por planos, eventos, ritmo y movimiento.
- Construir recetas de estilos con rasgos, limitaciones y estado de validación.
- Probar un fotograma clave antes de desarrollar la secuencia completa.
- Planificar acciones concretas mediante storyboard.
- Elegir gramática de animación según el contenido.
- Evaluar tanto fotogramas como reproducción a velocidad normal.
- Registrar prácticas que funcionaron y límites observados.

## Adaptaciones deliberadas
- La diversidad de estilo se conserva entre proyectos; no se impone una estética única.
- La coherencia interna de una pieza es una guía, no una prohibición de cambios estilísticos narrativos.
- La construcción vectorial/programática es prioritaria. El método de generar personajes con IA no se adopta como norma.
- Las duraciones, velocidades y umbrales de QA se determinan por el encargo y pruebas propias; no se copian números universales.
- Los sistemas de renderizado y QA del proyecto fuente son referencias técnicas, no dependencias obligatorias.

## Advertencias
El repositorio fuente contiene ejemplos, personajes y recursos con excepciones de licencia. Antes de reutilizar cualquier archivo concreto, revisar su licencia individual. La licencia general MIT no debe interpretarse como permiso universal para personajes, fuentes, imágenes o materiales de terceros.
