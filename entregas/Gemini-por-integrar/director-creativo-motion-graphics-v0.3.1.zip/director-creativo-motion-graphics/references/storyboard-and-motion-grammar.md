# Storyboard y gramática de movimiento

## Tabla de planos
Usa una fila por plano o evento:

`tiempo | sujeto/objeto | acción | cambio visual | foco | cámara | texto | transición | técnica`

El sujeto debe ser concreto. La acción debe describir un cambio visible, no verbos vagos como «aparece» o «se muestra».

## Estructura de una secuencia
- **Entrada:** establece una situación, sujeto o pregunta visual.
- **Desarrollo:** cambia el estado, revela información o ejecuta una acción.
- **Énfasis:** dirige la atención a un detalle o consecuencia.
- **Resolución:** completa la acción, responde o prepara el siguiente plano.

No todos los planos necesitan las cuatro fases. La duración depende de la complejidad de lectura y la acción, no de una cuota fija.

## Gramáticas frecuentes
- **Kinetic type:** movimiento ligado al significado y al ritmo de lectura.
- **Explainer/infografía:** relaciones, diagramas, escalas, secuencias y datos.
- **Editorial/collage:** capas, recortes, máscaras, fotografías y anotaciones.
- **Personaje/storytelling:** actuación, anticipación, reacción, continuidad y puesta en escena.
- **Abstracto:** sistemas visuales, reglas, variaciones, transformaciones y ritmo.
- **Interfaz/producto:** estados, jerarquía, foco, transiciones funcionales y microinteracciones.

## Cámara
La cámara puede permanecer fija. Si se mueve, debe revelar, conectar, orientar o enfatizar. Alterna movimientos por necesidad narrativa, no para cumplir una cuota. Distingue paneo, seguimiento, zoom, desplazamiento de capas y animación del propio objeto.

## Ritmo
Combina movimiento, quietud, repetición, pausa y cambio. No animes todos los elementos a la vez. El movimiento debe ayudar a entender o sentir algo.
