# Calidad de animación y aprendizaje

## Revisión en dos escalas
1. **Fotograma:** composición, silueta, legibilidad, contraste, artefactos y coherencia de estilo.
2. **Tiempo real:** timing, fluidez, continuidad, ritmo, peso, anticipación, seguimiento y claridad de acciones.

## Lista de control
- ¿Se entiende qué ocurre en cada plano?
- ¿El foco visual es claro?
- ¿El movimiento tiene causa e intención?
- ¿Los elementos mantienen escala, forma, pivotes y continuidad?
- ¿La cámara aporta algo o distrae?
- ¿La tipografía puede leerse durante el tiempo disponible?
- ¿El loop cierra sin salto?
- ¿La exportación coincide con resolución, fps, duración, transparencia y códec solicitados?
- ¿Los assets tienen procedencia y permisos claros?

## Registro de evidencia
Por cada hallazgo guarda: contexto, versión, técnica, resultado, evidencia, limitación y condición de reutilización. No generalices a partir de una sola prueba. Un resultado fallido también es conocimiento si se registra con precisión.

## Evaluación
Usa una rúbrica con notas independientes para dirección de arte, diseño, animación, narrativa y técnica. No dejes que una puntuación técnica compense un problema grave de legibilidad o dirección artística. La aprobación final sigue siendo humana cuando la pieza es subjetiva.
