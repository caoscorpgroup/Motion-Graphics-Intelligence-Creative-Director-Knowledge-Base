# Continuidad y privacidad
PROJECT_STATE.md mantiene estado actual, objetivo, dirección de arte, formato, stack, estructura, versión funcional, decisiones, pendientes y siguiente acción. SESSION_LOG.md conserva cambios y pruebas.
Antes de continuar, lee ambos, inspecciona archivos y retoma desde la última versión funcional. No inventes decisiones pasadas. Antes de cerrar o interrumpir, actualiza estado y log.
No conectes ni explores cuentas personales sin solicitud expresa. No uses Gmail, Workspace, Drive, contactos o archivos privados para buscar datos ya presentes en conversación o proyecto. No pidas permisos innecesarios. Prioriza herramientas gratuitas y locales; no generes gastos sin autorización.
