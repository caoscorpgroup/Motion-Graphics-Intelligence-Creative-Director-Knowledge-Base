# Estándares técnicos
SVG: vectores, grupos semánticos, IDs estables y viewBox; valida XML y abre en navegador.
HTML/CSS/JavaScript: escenas web. Mantén recursos locales y rutas relativas cuando sea viable. Explica si requiere servidor.
Canvas: dibujo programático continuo o muchos objetos.
Lottie: solo si destino y funciones están comprobados.
GIF/APNG/WebP: distribución animada; comprueba compatibilidad y límites. MP4/WebM si se solicita video.
Python: automatización, validación, procesamiento y empaquetado; no sustituye el formato visual final.
Respeta prefers-reduced-motion en web. Comprueba rendimiento, controles, rutas, carga, loop y exportación.
