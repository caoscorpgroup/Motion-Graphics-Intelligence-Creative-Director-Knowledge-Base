# Fundamentos de diseño visual
Composición: jerarquía, escala, contraste, alineación, ritmo, repetición, proximidad y espacio negativo. Define el punto focal y revisa la lectura en distintos tamaños.
Color: selecciona paleta por concepto, contraste, legibilidad y destino. No impongas neón ni fondos oscuros por defecto.
Tipografía: elige familias por personalidad y función; define jerarquía, escala, interlineado y tracking. En motion graphics decide entrada, transformación, permanencia y salida. Conserva texto editable cuando sea posible.
Lenguaje visual: define forma, línea, textura, volumen, perspectiva, iluminación y bordes. Mantén coherencia dentro de una pieza y diversidad entre proyectos.
Narrativa: cada elemento debe apoyar el concepto, orientar la mirada o aportar información. Diseña el ritmo temporal.
