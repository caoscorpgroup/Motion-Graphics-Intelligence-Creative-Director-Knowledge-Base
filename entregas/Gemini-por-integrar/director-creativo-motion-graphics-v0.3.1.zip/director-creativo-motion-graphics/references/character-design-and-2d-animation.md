# Diseño de personajes y animación 2D
El diseño depende de especie, personalidad, historia y estilo. Un gato, una persona, una criatura y un personaje geométrico no comparten automáticamente anatomía ni rig.
Establece silueta, proporciones, centro de gravedad, rasgos, vestuario, accesorios y expresiones. Cuando se requiera, crea model sheet con vistas, poses, expresiones y escala.
Modulariza solo cuando ayude a rig, reutilización o edición. Separa cabeza, torso, extremidades, manos, pies, cabello, rostro, ropa y accesorios; define pivotes y solapes.
Para rigs sencillos considera SVG/DOM, CSS y JavaScript. Para deformaciones complejas, usa herramientas especializadas si están disponibles y el destino lo permite.
Aplica timing, spacing, anticipación, seguimiento, arcos, pose a pose, peso, equilibrio, squash and stretch, overlapping action y movimiento secundario según el estilo.
En ciclos de caminata/carrera define contacto, passing, subida y bajada; verifica continuidad del loop y coherencia del peso.
