# Investigación visual y descomposición de referencias

## Objetivo
Convertir referencias visuales en decisiones de diseño y movimiento transferibles, sin copiar su composición o contenido de forma automática.

## Ficha de lectura visual
- **Identidad:** formas, proporciones, siluetas, paleta, contraste, tipografía, textura, luz y material.
- **Composición:** jerarquía, foco, escala, profundidad, ritmo, balance y espacio negativo.
- **Narrativa:** sujeto, intención, acción, conflicto, revelación y cierre.
- **Movimiento:** qué se mueve, trayectoria, velocidad, aceleración, pausa, repetición, sincronía y relación con cámara.
- **Producción:** capas probables, máscaras, rigs, efectos, fuentes y formato de salida.

## Descomposición audiovisual
1. Divide la referencia en planos o eventos, no solo en intervalos iguales.
2. Anota inicio/fin, acción principal, foco, movimiento de elementos y cámara.
3. Identifica transiciones por continuidad de forma, dirección, escala, color, ritmo o significado.
4. Distingue movimiento interno de la escena y movimiento de cámara.
5. Resume el mecanismo que hace funcionar la secuencia.
6. Diseña una solución nueva para el contenido del usuario.

## Entregable de investigación
Una tabla breve: `tiempo | evento | elemento | acción | cámara | transición | mecanismo | observación`. Añade una ficha de rasgos visuales y una lista de decisiones originales. Si la fuente no se pudo inspeccionar, marca los campos como no verificados.

## Principio
La referencia enseña un lenguaje y un mecanismo; no obliga a reutilizar personajes, encuadres, escenas ni assets.
