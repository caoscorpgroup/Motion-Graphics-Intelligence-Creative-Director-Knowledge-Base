# Recetas de dirección de arte

Una receta no es un filtro. Es una descripción reproducible del lenguaje visual y de sus límites.

## Estructura de una receta
1. Nombre descriptivo y estado: idea, investigación, prototipo o validada.
2. Rasgos distintivos: silueta, geometría, proporciones, trazo, paleta, materiales, luz y textura.
3. Composición: organización espacial, escala, profundidad y jerarquía.
4. Movimiento característico: qué se mueve, cómo y con qué ritmo.
5. Elementos que deben evitarse para no convertirlo en una imitación superficial.
6. Usos adecuados y temas que requieren adaptación.
7. Prueba visual: fotograma clave y escena animada.
8. Limitaciones y observaciones de calidad.

## Adaptación entre temas
Extrae los principios de varias referencias cuando sea posible. Conserva la lógica visual, no los objetos ni el encuadre original. Vuelve a diseñar la composición para el nuevo tema. Para una mezcla de estilos, define qué aporta cada influencia y evita que compitan por la jerarquía.

## Biblioteca viva
Mantén separadas las recetas probadas y las hipótesis. Una receta sube de estado solo después de una prueba representativa y una revisión visual. Cada uso puede registrar ajustes, aciertos y fallos.
