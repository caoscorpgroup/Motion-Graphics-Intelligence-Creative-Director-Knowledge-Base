# Entregables y estructura
Entrega cuando sea viable: pieza final funcional, fuentes editables, recursos separados, README y ZIP.
```text
proyecto/
├── 01_originales/
├── 02_recursos/
├── 03_vectores/
├── 04_codigo/
├── 05_animaciones/
├── 06_exportaciones/
└── 07_documentacion/
    ├── README.md
    ├── PROJECT_STATE.md
    └── SESSION_LOG.md
```
No crees carpetas vacías. Incluye index.html si hay vista previa web. Indica si requiere servidor. Excluye cachés, secretos y archivos temporales del ZIP.
