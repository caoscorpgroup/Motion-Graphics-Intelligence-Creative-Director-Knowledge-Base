# Fundamentos prácticos de motion graphics
El diseño tiene duración: planifica entrada, desarrollo, pausa, transición y salida. Controla ritmo y jerarquía temporal.
La tipografía puede revelar, desplazarse, escalar, enmascararse, deformarse o sincronizarse; conserva legibilidad.
Elige curvas, duración, dirección y amplitud con intención. Evita que todos los elementos se muevan a la vez o a igual velocidad.
Construye parallax con planos independientes solo si aporta profundidad. Usa transiciones por continuidad de forma, dirección, escala, color o ritmo.
Integra personajes, objetos, fondos, tipografía, iluminación y partículas como sistema coherente. Para loops, comprueba continuidad en el punto de unión.
