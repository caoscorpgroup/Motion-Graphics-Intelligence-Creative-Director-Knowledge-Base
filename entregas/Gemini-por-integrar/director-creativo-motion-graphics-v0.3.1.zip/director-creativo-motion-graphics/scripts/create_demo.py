from pathlib import Path
root=Path(__file__).resolve().parents[1];src=root/'templates/project-template';dst=root/'examples/editorial-motion-demo';dst.mkdir(parents=True,exist_ok=True)
for name in ('index.html','style.css','motion.js'):(dst/name).write_bytes((src/name).read_bytes())
print(dst/'index.html')
