from pathlib import Path
from playwright.sync_api import sync_playwright
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from threading import Thread
from functools import partial
import os

ROOT = Path(__file__).resolve().parents[1]
DEMO = ROOT / "examples" / "motion-intelligence-demo"

class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *_):
        pass

def main():
    errors = []
    html = (DEMO / "index.html").read_text()
    css = (DEMO / "style.css").read_text()
    js = (DEMO / "motion.js").read_text()
    html = html.replace('<link rel="stylesheet" href="style.css">', f'<style>{css}</style>')
    html = html.replace('<script src="motion.js"></script>', f'<script>{js}</script>')
    with sync_playwright() as p:
        launch_options = {"headless": True, "args": ["--no-sandbox"]}
        chromium_path = os.environ.get("CHROMIUM_PATH")
        if chromium_path:
            launch_options["executable_path"] = chromium_path
        browser = p.chromium.launch(**launch_options)
        page = browser.new_page(viewport={"width": 1280, "height": 720}, device_scale_factor=1)
        page.on("pageerror", lambda exc: errors.append(str(exc)))
        page.set_content(html, wait_until="load")
        page.wait_for_timeout(3600)
        page.screenshot(path=str(DEMO / "preview.png"))
        metrics = page.evaluate("""() => ({title: document.title, width: document.querySelector('.stage').getBoundingClientRect().width, height: document.querySelector('.stage').getBoundingClientRect().height, svg: !!document.querySelector('svg.scene'), animated: getComputedStyle(document.querySelector('.character')).animationName, characterOpacity: getComputedStyle(document.querySelector('.character')).opacity, keyframes: [...document.styleSheets].some(s => { try { return [...s.cssRules].some(r => r.type === CSSRule.KEYFRAMES_RULE); } catch(e) { return false; } })})""")
        browser.close()
    assert not errors, errors
    assert metrics["width"] == 1280, metrics
    assert metrics["height"] == 720, metrics
    assert metrics["svg"] and metrics["animated"] != "none" and metrics["keyframes"] and float(metrics["characterOpacity"]) > 0, metrics
    print({"status":"PASS", "browser_errors":errors, "metrics":metrics})

if __name__ == "__main__":
    main()
