#!/usr/bin/env python3
import argparse, colorsys, json
def parse_hex(value):
 s=value.strip().lstrip('#')
 if len(s)==3:s=''.join(c*2 for c in s)
 if len(s)!=6 or any(c not in '0123456789abcdefABCDEF' for c in s):raise ValueError('Color hexadecimal inválido')
 return tuple(int(s[i:i+2],16)/255 for i in (0,2,4))
def to_hex(rgb):return '#'+''.join(f'{round(max(0,min(1,c))*255):02X}' for c in rgb)
def harmony(color,mode='complementary'):
 r,g,b=parse_hex(color);h,l,s=colorsys.rgb_to_hls(r,g,b)
 offsets={'complementary':[0,180],'analogous':[-30,0,30],'triadic':[0,120,240],'split':[0,150,210],'tetradic':[0,90,180,270]}
 if mode not in offsets:raise ValueError('Armonía desconocida')
 return [to_hex(colorsys.hls_to_rgb((h+o/360)%1,l,s)) for o in offsets[mode]]
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('color');p.add_argument('--harmony',default='complementary');a=p.parse_args();print(json.dumps(harmony(a.color,a.harmony),indent=2))
