#!/usr/bin/env python3
import argparse
from pathlib import Path
import xml.etree.ElementTree as ET
SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 675"><title>Motion study</title><rect width="1200" height="675" fill="#090d19"/><g id="orbits" fill="none" stroke="#73e8ff" stroke-opacity=".55" stroke-width="2"><ellipse cx="830" cy="330" rx="340" ry="125" transform="rotate(-24 830 330)"/><ellipse cx="830" cy="330" rx="280" ry="190" transform="rotate(32 830 330)"/></g><g id="object"><circle cx="830" cy="330" r="112" fill="#314d9a"/><circle cx="795" cy="292" r="62" fill="#9df5ff" opacity=".85"/></g><g fill="#f4f6ff" font-family="Arial,sans-serif"><text x="82" y="170" font-size="22" letter-spacing="8">MOTION STUDY / 001</text><text x="76" y="360" font-size="112" font-weight="700">BEYOND</text><text x="82" y="420" font-size="24" fill="#73e8ff">THE SIGNAL</text></g></svg>"""
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',default='cover.svg');a=p.parse_args();path=Path(a.output);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(SVG,encoding='utf-8');ET.parse(path);print(path)
