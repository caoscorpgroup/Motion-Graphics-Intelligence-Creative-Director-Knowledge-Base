#!/usr/bin/env python3
import argparse, json
def fluid_type(min_px=24,max_px=120,min_vw=360,max_vw=1440):
 if min_px<=0 or max_px<min_px or min_vw<=0 or max_vw<=min_vw:raise ValueError('Rango inválido')
 slope=(max_px-min_px)/(max_vw-min_vw)*100;intercept=min_px-(slope/100)*min_vw
 return f'clamp({min_px}px, calc({intercept:.3f}px + {slope:.3f}vw), {max_px}px)'
def kinetic_title(text):
 safe=text.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
 return f'<h1 class="kinetic-title" aria-label="{safe}"><span>{safe}</span></h1>'
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--text',default='MOTION');a=p.parse_args();print(json.dumps({'font_size':fluid_type(),'html':kinetic_title(a.text)},indent=2))
