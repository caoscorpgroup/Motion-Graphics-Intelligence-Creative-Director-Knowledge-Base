# Director Creativo Integral de Motion Graphics

Skill portable basado en Agent Skills. Su propósito es dirigir y ejecutar diseño gráfico multidisciplinario con motion graphics como especialidad central. Construye ilustraciones vectoriales, personajes, escenas, tipografía, infografías y composiciones animadas.

## Instalación
Copia esta carpeta en el directorio de skills de tu agente. La ubicación depende de la plataforma; verifica la documentación vigente. El archivo principal es `SKILL.md`.

## Contenido
- `references/`: fundamentos, investigación visual, recetas de dirección de arte, storyboard, gramáticas de animación, calidad y continuidad.
- `workflows/`: producción gráfica y control de calidad.
- `scripts/`: utilidades auxiliares.
- `templates/`: plantilla de proyecto web con vista previa.
- `examples/`: demo editorial original y prueba de motion graphics vectorial.
- `tests/`: pruebas unitarias de base.

## Prototipo técnico de validación
Abre `examples/motion-intelligence-demo/index.html` en un navegador o reproduce `examples/motion-intelligence-demo/preview.mp4`. Es una prueba técnica original de SVG/CSS/JS editable, capas, tipografía, movimiento y exportación; **no es una muestra del acabado artístico que debe alcanzar cada proyecto**. La dirección de arte y el nivel de detalle deben adaptarse al encargo. Validación registrada: Chromium sin errores de consola; MP4 1280×720, 12 fps, 12.0 s.

## Referencia metodológica añadida
Se adaptaron métodos de análisis de referencias, recetas artísticas, storyboard por eventos, gramáticas de movimiento y control de calidad inspirados en `alchaincyf/huashu-art-motion`. No se importan sus assets ni se adopta su dependencia de generación de personajes por IA. Ver `references/huashu-method-adaptation.md`.

## Estado
Versión 0.3.1. Conserva los 27 archivos de la base 0.2 y añade metodología de investigación visual, dirección de arte, planificación por eventos, evaluación y una prueba práctica representativa.
