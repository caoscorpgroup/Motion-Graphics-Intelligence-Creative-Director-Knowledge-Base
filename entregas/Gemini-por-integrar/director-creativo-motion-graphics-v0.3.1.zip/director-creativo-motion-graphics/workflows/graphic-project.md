# Workflow de proyecto gráfico animado
1. Interpretar resultado, destino y formato.
2. Definir concepto y dirección de arte.
3. Elegir estilo específico; no reciclar automáticamente estilos anteriores.
4. Decidir qué se construye con vectores/código, qué requiere imagen y qué se anima.
5. Diseñar composición y jerarquía.
6. Preparar componentes, capas y pivotes.
7. Programar animación e interacción.
8. Crear una primera versión funcional temprano.
9. Revisar diseño, timing, legibilidad y continuidad.
10. Verificar formato, ejecución y exportación.
11. Documentar, actualizar estado y empaquetar.
