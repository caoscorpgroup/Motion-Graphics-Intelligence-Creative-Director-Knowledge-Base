# Control de calidad
Diseño: foco claro, estilo adecuado, tipografía legible, paleta coherente.
Construcción: capas independientes cuando hacen falta, pivotes correctos, texto editable, rutas válidas.
Movimiento: perceptible, deliberado, buen timing, loop sin salto, anatomía consistente.
Entrega: formato correcto, ejecución verificada, vista previa, fuentes, recursos, README, estado actualizado y ZIP íntegro.
No marques como aprobado algo que no hayas comprobado.
