# Biblioteca Contemporánea - Proyecto Interactivo 2D (Segunda Iteración)

Aplicación web interactiva desarrollada con estándares profesionales de Dirección de Arte, Motion Graphics, Rigging FK/IK analítico y Animación determinista en JavaScript y SVG.

## Características Principales

1. **Dirección de Arte y Personajes Diferenciados**:
   - **Librero (Don Ernesto)**: Adulto mayor con chalecto, gafas y barba, operando detrás del mostrador.
   - **Cliente (Carlos)**: Joven profesional con gabardina en recorrido activo por la biblioteca.
   - **Ayudante (Mateo)**: Joven dinámico con sudadera y gorra encargado del transporte de material.
   - **Niña (Sofía)**: Proporciones infantiles y extremidades articuladas mediante Cinemática Inversa (IK).

2. **Rigging y Cinemática**:
   - **Forward Kinematics (FK)**: Jerarquías de articulaciones con herencia de rotación para caminatas y gestos.
   - **Inverse Kinematics (IK)**: Algoritmo trigonométrico basado en la ley de cosenos para resolver con precisión matemática el alcance del brazo de la niña hacia el libro en la estantería.

3. **Modo X-Ray Dinámico**:
   - Visualización en tiempo real del esqueleto, huesos, pivotes y objetivos IK superpuestos sobre los personajes SVG.

4. **Sistema Temporal Centralizado (20s)**:
   - Motor determinista impulsado por `requestAnimationFrame` que controla la reproducción, pausa, loop, velocidad variable y desplazamiento manual (*scrubbing*) mediante barra de tiempo.

5. **Interacciones Dinámicas de Objetos**:
   - Transferencia y manipulación en tiempo real de libros entre estanterías, mostradores y personajes.

## Instrucciones de Ejecución

1. Descomprima el archivo ZIP.
2. Abra el archivo `index.html` en cualquier navegador web moderno (Google Chrome, Mozilla Firefox, Microsoft Edge, Safari).
3. Utilice los controles inferiores para reproducir, pausar, cambiar la velocidad o deslizar la línea de tiempo.
4. Active el interruptor **Modo X-Ray** para inspeccionar la estructura ósea y de rigging en tiempo real.
5. Haga clic en **Matriz de Auditoría** para revisar el cumplimiento técnico del proyecto.
