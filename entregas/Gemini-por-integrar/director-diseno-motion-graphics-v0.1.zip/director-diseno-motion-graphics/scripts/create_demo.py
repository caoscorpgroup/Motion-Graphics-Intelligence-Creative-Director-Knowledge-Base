#!/usr/bin/env python3
"""Crea un ejemplo local de portada editorial animada y sus fuentes."""
import argparse, shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--output',default='examples/editorial-motion-demo'); a=p.parse_args()
    out=Path(a.output); out.mkdir(parents=True,exist_ok=True)
    for name in ('index.html','style.css','motion.js'):
        shutil.copy2(ROOT/'templates/project-template'/name,out/name)
    (out/'README.md').write_text('# Portada editorial animada\n\nAbre `index.html` en un navegador moderno. Edita `style.css` para cambiar paleta, tipografía y movimiento; `motion.js` es el punto de entrada para lógica adicional. No requiere conexión ni dependencias externas.\n',encoding='utf-8')
    print(f'Proyecto creado en: {out.resolve()}')
if __name__=='__main__': main()
