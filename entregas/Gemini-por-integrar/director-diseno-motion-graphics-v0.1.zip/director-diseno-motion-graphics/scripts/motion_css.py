#!/usr/bin/env python3
"""Presets CSS para movimientos gráficos comunes."""
PRESETS={
 'fade-up': ('opacity: 0; transform: translateY(22px);','opacity: 1; transform: translateY(0);'),
 'slide-left': ('opacity: 0; transform: translateX(36px);','opacity: 1; transform: translateX(0);'),
 'scale-in': ('opacity: 0; transform: scale(.92);','opacity: 1; transform: scale(1);'),
 'rotate-in': ('opacity: 0; transform: rotate(-5deg) scale(.96);','opacity: 1; transform: rotate(0) scale(1);'),
}
def build(name, duration='800ms', delay='0ms', easing='cubic-bezier(.2,.75,.2,1)'):
    if name not in PRESETS: raise ValueError(f'Preset desconocido: {name}')
    start,end=PRESETS[name]
    return f'''/* Motion preset: {name} */\n.motion-{name} {{ animation: motion-{name} {duration} {easing} {delay} both; }}\n@keyframes motion-{name} {{ from {{ {start} }} to {{ {end} }} }}\n@media (prefers-reduced-motion: reduce) {{ .motion-{name} {{ animation: none; opacity: 1; transform: none; }} }}\n'''
