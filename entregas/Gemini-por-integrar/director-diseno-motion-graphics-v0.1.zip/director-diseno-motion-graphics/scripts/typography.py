#!/usr/bin/env python3
"""Genera CSS tipográfico fluido y una clase de entrada cinética."""
import argparse

def fluid_type(min_px=42, max_px=112, min_vw=360, max_vw=1440):
    if min_px <= 0 or max_px < min_px or min_vw <= 0 or max_vw <= min_vw:
        raise ValueError('Rangos tipográficos inválidos')
    slope=(max_px-min_px)/(max_vw-min_vw)*100
    intercept=min_px-(slope*min_vw/100)
    return f'clamp({min_px}px, {intercept:.3f}px + {slope:.3f}vw, {max_px}px)'

def kinetic_css(selector='.kinetic-title', duration='900ms', distance='24px'):
    if not selector.startswith('.') and not selector.startswith('#'):
        raise ValueError('Usa un selector de clase o ID')
    return f'''{selector} {{ animation: kinetic-enter {duration} cubic-bezier(.2,.75,.2,1) both; }}\n@keyframes kinetic-enter {{ from {{ opacity: 0; transform: translateY({distance}); }} to {{ opacity: 1; transform: translateY(0); }} }}\n@media (prefers-reduced-motion: reduce) {{ {selector} {{ animation: none; }} }}\n'''

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--min',type=int,default=42); p.add_argument('--max',type=int,default=112); a=p.parse_args()
    print(':root { --type-display: '+fluid_type(a.min,a.max)+'; }')
    print(kinetic_css())
if __name__=='__main__': main()
