#!/usr/bin/env python3
"""Divide una imagen en celdas uniformes. Requiere Pillow opcionalmente."""
import argparse
from pathlib import Path

def split_image(source, output_dir, columns, rows, prefix='frame'):
    try:
        from PIL import Image
    except ImportError as exc:
        raise RuntimeError('Esta función necesita Pillow. Instálalo solo si vas a cortar sprites: pip install Pillow') from exc
    if columns < 1 or rows < 1: raise ValueError('Filas y columnas deben ser positivas')
    image=Image.open(source).convert('RGBA')
    if image.width % columns or image.height % rows:
        raise ValueError('El tamaño de la imagen debe dividirse exactamente entre filas y columnas')
    w,h=image.width//columns,image.height//rows
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True)
    paths=[]
    for index in range(columns*rows):
        col,row=index%columns,index//columns
        crop=image.crop((col*w,row*h,(col+1)*w,(row+1)*h))
        path=out/f'{prefix}_{index:03d}.png'; crop.save(path); paths.append(str(path))
    return {'frame_width':w,'frame_height':h,'columns':columns,'rows':rows,'frames':paths}

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('source'); p.add_argument('output_dir'); p.add_argument('--columns',type=int,required=True); p.add_argument('--rows',type=int,required=True); a=p.parse_args()
    print(split_image(a.source,a.output_dir,a.columns,a.rows))
if __name__=='__main__': main()
