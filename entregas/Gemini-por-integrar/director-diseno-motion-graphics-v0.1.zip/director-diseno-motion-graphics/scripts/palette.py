#!/usr/bin/env python3
"""Utilidades pequeñas de color sin dependencias externas."""
import argparse, colorsys, json

def hex_to_rgb(value):
    value = value.strip().lstrip('#')
    if len(value) == 3:
        value = ''.join(ch * 2 for ch in value)
    if len(value) != 6:
        raise ValueError('El color debe tener 3 o 6 dígitos hexadecimales')
    try:
        return tuple(int(value[i:i+2], 16) for i in (0, 2, 4))
    except ValueError as exc:
        raise ValueError('Color hexadecimal inválido') from exc

def rgb_to_hex(rgb):
    return '#%02x%02x%02x' % tuple(max(0, min(255, round(v))) for v in rgb)

def harmony(base, kind='complementary'):
    r, g, b = (v / 255 for v in hex_to_rgb(base))
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    shifts = {'complementary': [0, .5], 'analogous': [-1/12, 0, 1/12], 'triadic': [0, 1/3, 2/3], 'split-complementary': [0, 5/12, 7/12]}
    if kind not in shifts:
        raise ValueError(f'Armonía no reconocida: {kind}')
    return [rgb_to_hex(tuple(c * 255 for c in colorsys.hsv_to_rgb((h + d) % 1, s, v))) for d in shifts[kind]]

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('base', help='Color base, por ejemplo #8e79ff')
    p.add_argument('--harmony', choices=['complementary','analogous','triadic','split-complementary'], default='complementary')
    args = p.parse_args()
    print(json.dumps({'base': args.base, 'harmony': args.harmony, 'palette': harmony(args.base, args.harmony)}, indent=2))
if __name__ == '__main__': main()
