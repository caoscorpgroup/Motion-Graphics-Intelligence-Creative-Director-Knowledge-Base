#!/usr/bin/env python3
"""Genera SVG escalable básico sin bibliotecas externas."""
import argparse
from xml.etree import ElementTree as ET

def poster_svg(width=1080, height=1350, title='DISEÑO EN MOVIMIENTO', accent='#a9ffdf'):
    if width <= 0 or height <= 0: raise ValueError('Las dimensiones deben ser positivas')
    safe_title = title.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img" aria-labelledby="title desc">
<title id="title">{safe_title}</title><desc id="desc">Cartel vectorial editable con tipografía y formas geométricas.</desc>
<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#101725"/><stop offset="1" stop-color="#090b13"/></linearGradient><radialGradient id="glow"><stop stop-color="{accent}" stop-opacity=".9"/><stop offset="1" stop-color="{accent}" stop-opacity="0"/></radialGradient></defs>
<rect width="100%" height="100%" fill="url(#bg)"/><circle cx="{width*.76:.1f}" cy="{height*.28:.1f}" r="{min(width,height)*.25:.1f}" fill="url(#glow)"/>
<path d="M {width*.08:.1f} {height*.72:.1f} L {width*.92:.1f} {height*.72:.1f}" stroke="{accent}" stroke-opacity=".8" stroke-width="2"/>
<text x="{width*.08:.1f}" y="{height*.13:.1f}" fill="#d4d7df" font-family="Arial,sans-serif" font-size="{width*.018:.1f}" letter-spacing="5">PUBLICACIÓN DIGITAL / 2026</text>
<text x="{width*.08:.1f}" y="{height*.49:.1f}" fill="#f1eee8" font-family="Arial,sans-serif" font-size="{width*.09:.1f}" font-weight="700">{safe_title}</text>
<text x="{width*.08:.1f}" y="{height*.78:.1f}" fill="#c4c7d2" font-family="Arial,sans-serif" font-size="{width*.022:.1f}">COMPOSICIÓN VECTORIAL · EDITABLE</text></svg>'''

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('output'); p.add_argument('--width',type=int,default=1080); p.add_argument('--height',type=int,default=1350); p.add_argument('--title',default='DISEÑO EN MOVIMIENTO'); p.add_argument('--accent',default='#a9ffdf'); a=p.parse_args()
    content=poster_svg(a.width,a.height,a.title,a.accent)
    ET.fromstring(content)
    with open(a.output,'w',encoding='utf-8') as f: f.write(content)
if __name__=='__main__': main()
