# Motion graphics

Diseñar primero la composición y después el movimiento, pero planificar ambos juntos.

- Definir duración, FPS, formato, resolución, zona segura y destino.
- Separar fondo, sujeto, texto, vectores y efectos en capas editables.
- Usar transformaciones (posición, escala, rotación, opacidad) antes que regenerar fotogramas completos.
- Preferir SVG para formas y texto vectorial; CSS para transiciones simples; JavaScript/Canvas para lógica, partículas y secuencias complejas.
- Aplicar easing coherente, anticipación, aceleración/desaceleración y pausas para lectura.
- Para loops, comprobar continuidad entre último y primer fotograma.
- Reducir movimiento si compromete legibilidad o accesibilidad.
- Sprite sheets: usar celdas uniformes, dimensiones consistentes, transparencia cuando proceda y metadatos de FPS/orden.
- GIF tiene limitaciones de color y transparencia; preferir WebP/APNG/MP4 cuando destino y compatibilidad lo permitan.
