# Estándares técnicos y compatibilidad

## Entrega
Documentar dimensiones en píxeles, relación de aspecto, FPS, duración, espacio de color, formato y plataforma objetivo.

## Formatos
SVG para vectores; PNG/WebP para raster; HTML/CSS/JS para composición programable; GIF/APNG/WebP animado para loops; MP4/WebM para video. Verificar el soporte real del destino antes de elegir.

## Color y exportación
RGB para pantallas; CMYK y perfil ICC apropiado para impresión, confirmando especificaciones de imprenta. Incluir sangrado y zona segura cuando corresponda.

## Accesibilidad
Contraste suficiente, tipografía legible, evitar destellos rápidos y ofrecer alternativa estática cuando sea pertinente.

## Licencias y dependencias
Registrar procedencia y licencia de recursos externos. No cargar librerías remotas por defecto; preferir código propio y dependencias locales identificadas.
