# Fundamentos visuales

## Color
Construir paletas con función y jerarquía: base, superficie, acento, texto y estados. Revisar contraste y legibilidad en el medio de destino. El simbolismo del color depende de cultura, contexto y audiencia; evitar afirmaciones psicológicas absolutas.

## Tipografía
Priorizar legibilidad, jerarquía, ritmo y personalidad. Limitar familias y pesos salvo que el concepto justifique lo contrario. Verificar disponibilidad/licencia de fuentes y definir alternativas seguras.

## Composición
Establecer retícula, alineaciones, márgenes, espacio negativo, foco y orden de lectura. Para movimiento, definir capas y trayectorias desde el inicio; conservar estabilidad suficiente para que el contenido sea legible.

## Dirección de arte
Mantener coherencia de paleta, formas, textura, iluminación, perspectiva y lenguaje visual. Las referencias inspiran; no se copian literalmente obras protegidas.
