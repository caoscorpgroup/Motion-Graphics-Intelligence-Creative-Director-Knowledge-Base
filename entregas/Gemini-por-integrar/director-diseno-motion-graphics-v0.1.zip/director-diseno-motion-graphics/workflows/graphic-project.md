# Workflow: proyecto gráfico estático + movimiento

1. Confirmar propósito, destino, formato, tamaño, duración y referencias.
2. Crear brief breve y dirección visual.
3. Diseñar composición estática con retícula, paleta y jerarquía.
4. Descomponer en capas semánticas: fondo, imagen, títulos, ornamentos y efectos.
5. Identificar capas animables y definir su función narrativa.
6. Implementar movimiento con CSS/SVG/JS según complejidad.
7. Crear versión estática y animada.
8. Revisar lectura, ritmo, contraste, continuidad y rendimiento.
9. Empaquetar fuentes, recursos, exportaciones y guía de edición en ZIP.
