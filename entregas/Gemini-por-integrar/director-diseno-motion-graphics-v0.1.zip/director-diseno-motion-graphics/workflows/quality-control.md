# Control de calidad

## Revisión técnica
- [ ] Archivos y rutas existen.
- [ ] SVG/XML/JSON parsean correctamente.
- [ ] HTML/CSS/JS no contienen errores obvios.
- [ ] Dimensiones, FPS y duración coinciden con el brief.
- [ ] Recursos y dependencias están incluidos o documentados.
- [ ] El proyecto abre sin conexión si se prometió funcionamiento local.
- [ ] ZIP contiene fuentes y exportaciones.

## Revisión visual
- [ ] Jerarquía y foco claros.
- [ ] Tipografía legible.
- [ ] Paleta coherente y contraste suficiente.
- [ ] Movimiento intencional y no distractor.
- [ ] Transiciones y loop continuos cuando corresponda.
- [ ] Composición consistente entre estados.
- [ ] Versión estática disponible cuando sea útil.

No marcar una casilla como superada sin haber realizado la comprobación.
