# Director de Diseño Gráfico y Motion Graphics

Skill y kit inicial de producción gráfica modular. Prioriza diseño gráfico en movimiento, archivos editables, SVG y tecnologías web abiertas; no es un generador de video como función principal.

## Contenido
- `SKILL.md`: identidad, reglas, especialidades y flujo operativo.
- `references/`: criterios técnicos y visuales.
- `workflows/`: procesos de producción.
- `scripts/`: utilidades Python sin dependencias obligatorias.
- `templates/`: base de proyecto HTML/CSS/JS.
- `tests/`: pruebas automatizadas.
- `examples/`: ejemplo de portada editorial animada.

## Requisitos
- Python 3.9+ para scripts y pruebas.
- Navegador moderno para abrir los proyectos HTML.
- No requiere servicios de pago ni conexión de red para el ejemplo incluido.

## Generar ejemplo
Desde la raíz del repositorio:

```bash
python scripts/create_demo.py --output examples/editorial-motion-demo
```

Abre `examples/editorial-motion-demo/index.html` en un navegador.

## Probar

```bash
python -m unittest discover -s tests -v
```

## Nota
El paquete es una primera versión técnica. La calidad estética final requiere pruebas creativas iterativas con la IA/plataforma donde se instale el skill. No se afirma compatibilidad de instalación universal: Agent Skills aporta una estructura portable, pero cada plataforma decide cómo cargar skills y qué herramientas concede.

## Scripts disponibles
- `scripts/palette.py`: genera armonías cromáticas desde un color hexadecimal.
- `scripts/svg_shapes.py`: genera un cartel vectorial SVG válido.
- `scripts/typography.py`: genera escala tipográfica fluida y entrada cinética accesible.
- `scripts/motion_css.py`: presets CSS de entrada (fade-up, slide-left, scale-in, rotate-in).
- `scripts/sprite_sheet.py`: divide una hoja en fotogramas uniformes; Pillow es opcional y solo se requiere para esta operación.
- `scripts/create_demo.py`: crea un ejemplo editorial local sin dependencias.

Los scripts son utilidades iniciales reutilizables. No reemplazan un motor de renderizado completo ni garantizan exportar cualquier formato en todos los entornos.
