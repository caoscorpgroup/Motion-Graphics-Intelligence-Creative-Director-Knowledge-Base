import sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import palette, svg_shapes, typography, motion_css
from xml.etree import ElementTree as ET

class PaletteTests(unittest.TestCase):
    def test_hex_short_and_long(self):
        self.assertEqual(palette.hex_to_rgb('#abc'),(170,187,204))
        self.assertEqual(palette.hex_to_rgb('#aabbcc'),(170,187,204))
    def test_harmony_counts(self):
        self.assertEqual(len(palette.harmony('#8e79ff','complementary')),2)
        self.assertEqual(len(palette.harmony('#8e79ff','triadic')),3)
    def test_invalid_color(self):
        with self.assertRaises(ValueError): palette.hex_to_rgb('nope')

class MotionTests(unittest.TestCase):
    def test_fluid_type_is_clamped(self):
        self.assertTrue(typography.fluid_type().startswith('clamp('))
    def test_motion_preset_respects_reduced_motion(self):
        self.assertIn('prefers-reduced-motion', motion_css.build('fade-up'))
    def test_unknown_preset_fails(self):
        with self.assertRaises(ValueError): motion_css.build('spin-unicorn')

class SvgTests(unittest.TestCase):
    def test_svg_is_well_formed(self):
        root=ET.fromstring(svg_shapes.poster_svg())
        self.assertTrue(root.tag.endswith('svg'))
    def test_dimensions_must_be_positive(self):
        with self.assertRaises(ValueError): svg_shapes.poster_svg(0,100)

if __name__=='__main__': unittest.main()
