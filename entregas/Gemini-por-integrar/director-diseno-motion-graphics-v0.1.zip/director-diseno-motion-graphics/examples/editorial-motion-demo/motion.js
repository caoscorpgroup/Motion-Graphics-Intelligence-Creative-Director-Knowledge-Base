// Punto de entrada para animaciones adicionales sin dependencias externas.
// Respeta prefers-reduced-motion y mantiene el contenido accesible.
(() => { const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches; if (reduceMotion) document.documentElement.classList.add('reduced-motion'); })();
