# Portada editorial animada

Abre `index.html` en un navegador moderno. Edita `style.css` para cambiar paleta, tipografía y movimiento; `motion.js` es el punto de entrada para lógica adicional. No requiere conexión ni dependencias externas.
